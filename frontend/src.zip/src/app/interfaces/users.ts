export interface User {
    Rut: string;
    Nombre: string;
    Correo_electronico: string;
    Contrasena: string;
    Region: string;
    Comuna: string;
}
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ControlPage } from './control.page';

describe('ControlRobotPage', () => {
  let component: ControlPage;
  let fixture: ComponentFixture<ControlPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
